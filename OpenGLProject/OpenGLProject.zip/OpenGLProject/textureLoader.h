#pragma once

#include <glad/glad.h>

class TextureLoader
{
public:
	GLuint LoadTexture(const char* path);
};

