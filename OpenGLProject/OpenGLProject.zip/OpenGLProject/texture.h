#pragma once
#include <string>

class Texture {
public:
	Texture() {
	}

	std::string diffusePath = "";
	std::string roughnessPath = "";
	std::string normalPath = "";
};